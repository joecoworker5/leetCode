package com.cathaybk.practice.nt87944.b;

public interface IWork {
     public void printInfo();
}
