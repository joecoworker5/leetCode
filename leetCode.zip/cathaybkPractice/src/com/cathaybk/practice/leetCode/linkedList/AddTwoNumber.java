package com.cathaybk.practice.leetCode.linkedList;

public class AddTwoNumber {

    public static void main(String[] args) {
        LinkedList listOne = new LinkedList(2);
        listOne.pushfront(4);
        listOne.pushfront(3);
        LinkedList listTwo = new LinkedList(5);
        listTwo.pushfront(6);
        listTwo.pushfront(4);

    }

    public ListNode addTwoNumbers(ListNode l1, ListNode l2) {
        int sum = newhead1.val + newhead2.val;
        int quotient = sum / 10;
        int remainder = sum % 10;
        ListNode newNode = new ListNode(quotient);
    }

    //數字太大會爆掉
    public ListNode addTwoNumbersWrong(ListNode l1, ListNode l2) {
        ListNode newhead1 = reverseList(l1);
        String number1 = "";
        while (newhead1 != null) {
            number1 += newhead1.val;
            newhead1 = newhead1.next;
        }
        String number2 = "";
        ListNode newhead2 = reverseList(l2);
        while (newhead2 != null) {
            number2 += newhead2.val;
            newhead2 = newhead2.next;
        }
        Long total = Long.valueOf(number1) + Long.valueOf(number2);
        ListNode previous = null;
        for (int i = 0; i <= total.toString().length() - 1; i++) {
            ListNode listNode = new ListNode();
            listNode.next = previous;
            listNode.val = Integer.valueOf(total.toString().substring(i, i + 1));
            previous = listNode;
        }

        return previous;

    }

    public ListNode reverseList(ListNode head) {
        if (head == null || head.next == null) {
            return head;
        }

        ListNode previous = null;
        ListNode current = head;
        ListNode preceding = head.next;

        while (preceding != null) {
            current.next = previous;
            previous = current;
            current = preceding;
            preceding = preceding.next;
        }

        current.next = previous;
        return current;
    }

}
