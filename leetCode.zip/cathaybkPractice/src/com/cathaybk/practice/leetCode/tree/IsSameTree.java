package com.cathaybk.practice.leetCode.tree;

import java.util.ArrayList;
import java.util.List;

public class IsSameTree {

    public static void main(String[] args) {

    }

    public boolean isSameTree(TreeNode p, TreeNode q) {
        List<Integer> resultOne = levelorderTraversal(p);
        List<Integer> resultTwo = levelorderTraversal(q);
        if (resultOne.size() != resultTwo.size()) {
            return false;
        }
        int i = 0;
        while (i < resultOne.size()) {
            if (!resultOne.get(i).equals(resultTwo.get(i)))
                return false;
            i++;
        }
        
        return true;
    }

    //iterate
    public List<Integer> levelorderTraversal(TreeNode root) {
        List<Integer> levelorderList = new ArrayList<>();
        List<TreeNode> list = new ArrayList<>();
        TreeNode current = root;
        list.add(current);
        while (list.stream().anyMatch(e -> e != null)) {
            levelorderList.add(current != null ? current.val : null);
            list.add(current != null ? current.left : null);
            list.add(current != null ? current.right : null);
            list.remove(0);
            current = list.get(0);
        }

        return levelorderList;
    }

}
