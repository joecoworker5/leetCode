package com.cathaybk.practice.leetCode.tree;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class BinaryTree {

    TreeNode root;

    public BinaryTree() {
    }

    public BinaryTree(TreeNode root) {
        this.root = root;
    }

    List<Integer> inorderList = new ArrayList<>();

    List<Integer> preorderList = new ArrayList<>();

    //iterate
    public List<Integer> levelorderTraversal(TreeNode root) {
        List<Integer> levelorderList = new ArrayList<>();
        List<TreeNode> list = new ArrayList<>();
        TreeNode current = root;
        list.add(current);
        while (list.stream().anyMatch(e -> e != null)) {
            levelorderList.add(current != null ? current.val : null);
            list.add(current != null ? current.left : null);
            list.add(current != null ? current.right : null);
            list.remove(0);
            current = list.get(0);
        }

        return levelorderList;

    }

    //recursion
    public List<Integer> preorderTraversal(TreeNode root) {
        TreeNode current = root;
        if (current != null) {
            preorderList.add(current.val);
            preorderTraversal(current.left);
            preorderTraversal(current.right);
        }
        return preorderList;
    }

    //recursion
    public List<Integer> inorderTraversal(TreeNode root) {
        TreeNode current = root;
        if (current != null) {
            inorderTraversal(root.left);
            inorderList.add(root.val);
            inorderTraversal(root.right);
        }

        return inorderList;

    }

    //iterate
    public List<Integer> inorderTraversalIterate(TreeNode root) {
        TreeNode p = root;
        List<Integer> inorder = new ArrayList<>();
        List<TreeNode> list = new ArrayList<>();
        while (p != null || !list.isEmpty()) {
            while (p != null) {
                list.add(p);
                p = p.left;
            }

            p = list.get(list.size() - 1);
            list.remove(list.size() - 1);
            inorder.add(p.val);
            p = p.right;
        }

        return inorder;

    }
}
